const express = require('express');
const fs = require('fs');
const app = express();
var filepath = __dirname + '/' + 'test.txt';
function get_line(filepath, line_no, callback) {
    fs.readFile(filepath, function (err, data) {
      if (err) throw err;
      var lines = data.toString('utf-8').split("\n");

      if(+line_no > lines.length){
        return callback('File end reached without finding line', null);
      }
      callback(null, lines[+line_no]);
    });
}
get_line(filepath, 1, function(err, line){
  console.log('The line: ' + line);
})
app.get('/',(req,res)=>{
    
    res.sendFile(filepath);
})
app.listen(4000);
console.log('app running on 4000')